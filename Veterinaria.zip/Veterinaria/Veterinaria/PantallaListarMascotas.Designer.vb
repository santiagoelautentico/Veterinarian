﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PantallaListarMascotas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListaPersonas = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.InicioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListarPersonasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListarMascotasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListaPersonas
        '
        Me.ListaPersonas.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.ListaPersonas.FullRowSelect = True
        Me.ListaPersonas.GridLines = True
        Me.ListaPersonas.HideSelection = False
        Me.ListaPersonas.Location = New System.Drawing.Point(33, 79)
        Me.ListaPersonas.MultiSelect = False
        Me.ListaPersonas.Name = "ListaPersonas"
        Me.ListaPersonas.Size = New System.Drawing.Size(348, 192)
        Me.ListaPersonas.TabIndex = 24
        Me.ListaPersonas.UseCompatibleStateImageBehavior = False
        Me.ListaPersonas.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 40
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "CI Dueño"
        Me.ColumnHeader2.Width = 88
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Nombre"
        Me.ColumnHeader3.Width = 91
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Año de nacimiento"
        Me.ColumnHeader4.Width = 125
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InicioToolStripMenuItem, Me.MToolStripMenuItem, Me.ListarPersonasToolStripMenuItem, Me.ListarMascotasToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(614, 24)
        Me.MenuStrip1.TabIndex = 25
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'InicioToolStripMenuItem
        '
        Me.InicioToolStripMenuItem.Name = "InicioToolStripMenuItem"
        Me.InicioToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.InicioToolStripMenuItem.Text = "Inicio"
        '
        'MToolStripMenuItem
        '
        Me.MToolStripMenuItem.Name = "MToolStripMenuItem"
        Me.MToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.MToolStripMenuItem.Text = "Mascota"
        '
        'ListarPersonasToolStripMenuItem
        '
        Me.ListarPersonasToolStripMenuItem.Name = "ListarPersonasToolStripMenuItem"
        Me.ListarPersonasToolStripMenuItem.Size = New System.Drawing.Size(97, 20)
        Me.ListarPersonasToolStripMenuItem.Text = "Listar Personas"
        '
        'ListarMascotasToolStripMenuItem
        '
        Me.ListarMascotasToolStripMenuItem.Name = "ListarMascotasToolStripMenuItem"
        Me.ListarMascotasToolStripMenuItem.Size = New System.Drawing.Size(100, 20)
        Me.ListarMascotasToolStripMenuItem.Text = "Listar Mascotas"
        '
        'PBLogo
        '
        Me.PBLogo.Image = Global.Veterinaria.My.Resources.Resources.LogoVeterinaria
        Me.PBLogo.Location = New System.Drawing.Point(458, 79)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(144, 164)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PBLogo.TabIndex = 26
        Me.PBLogo.TabStop = False
        '
        'PantallaListarMascotas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(614, 311)
        Me.Controls.Add(Me.PBLogo)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.ListaPersonas)
        Me.Name = "PantallaListarMascotas"
        Me.Text = "PantallaListarMascotas"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListaPersonas As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents InicioToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ListarPersonasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ListarMascotasToolStripMenuItem As ToolStripMenuItem
End Class
