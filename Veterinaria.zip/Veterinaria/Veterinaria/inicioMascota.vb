﻿Public Class inicioMascota

    Private Sub ButtonInicio_Click(sender As Object, e As EventArgs) Handles ButtonInicio.Click
        Dim ID As Integer
        ID = tbxID.Text

        Dim CI As Integer
        CI = tbxCI.Text

        Dim Nombre As String
        Nombre = tbxNom.Text

        Dim AñoNacimiento As String
        AñoNacimiento = tbxAnio.Text

        Dim Resultado As String
        Resultado = ID & " " & CI & " " & Nombre & " " & AñoNacimiento


        tbxRes.Text = Resultado

    End Sub

    Private Sub MascotaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MascotaToolStripMenuItem.Click
        inicioPersona.Show()
    End Sub

    Private Sub InicioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InicioToolStripMenuItem.Click
        inicio.Show()
    End Sub

    Private Sub ListarPersonasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListarPersonasToolStripMenuItem.Click
        PantallaListar.Show()
    End Sub

    Private Sub ListarMascotasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListarMascotasToolStripMenuItem.Click
        PantallaListarMascotas.Show()
    End Sub

    Private Sub LabelCI_Click(sender As Object, e As EventArgs) Handles LabelCI.Click

    End Sub
End Class