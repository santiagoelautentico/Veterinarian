﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class inicioPersona
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelTituloP = New System.Windows.Forms.Label()
        Me.tbxDirecc = New System.Windows.Forms.TextBox()
        Me.ButtonInicio = New System.Windows.Forms.Button()
        Me.tbxCI = New System.Windows.Forms.TextBox()
        Me.tbxNom = New System.Windows.Forms.TextBox()
        Me.LabelDirec = New System.Windows.Forms.Label()
        Me.LabelNom = New System.Windows.Forms.Label()
        Me.LabelCi = New System.Windows.Forms.Label()
        Me.tbxRes = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.InicioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.listadordePersonasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListarMascotasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnTel = New System.Windows.Forms.Button()
        Me.listaTelefonos = New System.Windows.Forms.ListView()
        Me.tbxTelefono = New System.Windows.Forms.TextBox()
        Me.lbTelefono = New System.Windows.Forms.Label()
        Me.btnMod = New System.Windows.Forms.Button()
        Me.ButtonBuscar = New System.Windows.Forms.Button()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelTituloP
        '
        Me.LabelTituloP.AutoSize = True
        Me.LabelTituloP.Font = New System.Drawing.Font("Century Gothic", 35.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTituloP.Location = New System.Drawing.Point(25, 24)
        Me.LabelTituloP.Name = "LabelTituloP"
        Me.LabelTituloP.Size = New System.Drawing.Size(420, 57)
        Me.LabelTituloP.TabIndex = 0
        Me.LabelTituloP.Text = "Inicio de persona"
        '
        'tbxDirecc
        '
        Me.tbxDirecc.Location = New System.Drawing.Point(169, 192)
        Me.tbxDirecc.Name = "tbxDirecc"
        Me.tbxDirecc.Size = New System.Drawing.Size(170, 20)
        Me.tbxDirecc.TabIndex = 1
        '
        'ButtonInicio
        '
        Me.ButtonInicio.Location = New System.Drawing.Point(63, 308)
        Me.ButtonInicio.Name = "ButtonInicio"
        Me.ButtonInicio.Size = New System.Drawing.Size(142, 50)
        Me.ButtonInicio.TabIndex = 2
        Me.ButtonInicio.Text = "Aceptar"
        Me.ButtonInicio.UseVisualStyleBackColor = True
        '
        'tbxCI
        '
        Me.tbxCI.Location = New System.Drawing.Point(169, 111)
        Me.tbxCI.Name = "tbxCI"
        Me.tbxCI.Size = New System.Drawing.Size(170, 20)
        Me.tbxCI.TabIndex = 3
        '
        'tbxNom
        '
        Me.tbxNom.Location = New System.Drawing.Point(169, 151)
        Me.tbxNom.Name = "tbxNom"
        Me.tbxNom.Size = New System.Drawing.Size(170, 20)
        Me.tbxNom.TabIndex = 4
        '
        'LabelDirec
        '
        Me.LabelDirec.AutoSize = True
        Me.LabelDirec.Font = New System.Drawing.Font("Candara Light", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDirec.Location = New System.Drawing.Point(35, 181)
        Me.LabelDirec.Name = "LabelDirec"
        Me.LabelDirec.Size = New System.Drawing.Size(118, 33)
        Me.LabelDirec.TabIndex = 5
        Me.LabelDirec.Text = "Dirección"
        '
        'LabelNom
        '
        Me.LabelNom.AutoSize = True
        Me.LabelNom.Font = New System.Drawing.Font("Candara Light", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNom.Location = New System.Drawing.Point(35, 140)
        Me.LabelNom.Name = "LabelNom"
        Me.LabelNom.Size = New System.Drawing.Size(108, 33)
        Me.LabelNom.TabIndex = 6
        Me.LabelNom.Text = "Nombre"
        '
        'LabelCi
        '
        Me.LabelCi.AutoSize = True
        Me.LabelCi.Font = New System.Drawing.Font("Candara Light", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelCi.Location = New System.Drawing.Point(35, 99)
        Me.LabelCi.Name = "LabelCi"
        Me.LabelCi.Size = New System.Drawing.Size(37, 33)
        Me.LabelCi.TabIndex = 7
        Me.LabelCi.Text = "CI"
        '
        'tbxRes
        '
        Me.tbxRes.AutoSize = True
        Me.tbxRes.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.tbxRes.Location = New System.Drawing.Point(60, 374)
        Me.tbxRes.Name = "tbxRes"
        Me.tbxRes.Size = New System.Drawing.Size(17, 17)
        Me.tbxRes.TabIndex = 8
        Me.tbxRes.Text = "X"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InicioToolStripMenuItem, Me.MToolStripMenuItem, Me.listadordePersonasToolStripMenuItem, Me.ListarMascotasToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(614, 24)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'InicioToolStripMenuItem
        '
        Me.InicioToolStripMenuItem.Name = "InicioToolStripMenuItem"
        Me.InicioToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.InicioToolStripMenuItem.Text = "Inicio"
        '
        'MToolStripMenuItem
        '
        Me.MToolStripMenuItem.Name = "MToolStripMenuItem"
        Me.MToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.MToolStripMenuItem.Text = "Mascota"
        '
        'listadordePersonasToolStripMenuItem
        '
        Me.listadordePersonasToolStripMenuItem.Name = "listadordePersonasToolStripMenuItem"
        Me.listadordePersonasToolStripMenuItem.Size = New System.Drawing.Size(97, 20)
        Me.listadordePersonasToolStripMenuItem.Text = "Listar Personas"
        '
        'ListarMascotasToolStripMenuItem
        '
        Me.ListarMascotasToolStripMenuItem.Name = "ListarMascotasToolStripMenuItem"
        Me.ListarMascotasToolStripMenuItem.Size = New System.Drawing.Size(100, 20)
        Me.ListarMascotasToolStripMenuItem.Text = "Listar Mascotas"
        '
        'btnTel
        '
        Me.btnTel.Location = New System.Drawing.Point(345, 227)
        Me.btnTel.Name = "btnTel"
        Me.btnTel.Size = New System.Drawing.Size(30, 23)
        Me.btnTel.TabIndex = 10
        Me.btnTel.Text = "+"
        Me.btnTel.UseVisualStyleBackColor = True
        '
        'listaTelefonos
        '
        Me.listaTelefonos.HideSelection = False
        Me.listaTelefonos.Location = New System.Drawing.Point(403, 181)
        Me.listaTelefonos.Name = "listaTelefonos"
        Me.listaTelefonos.Scrollable = False
        Me.listaTelefonos.Size = New System.Drawing.Size(199, 97)
        Me.listaTelefonos.TabIndex = 11
        Me.listaTelefonos.UseCompatibleStateImageBehavior = False
        Me.listaTelefonos.View = System.Windows.Forms.View.List
        '
        'tbxTelefono
        '
        Me.tbxTelefono.Location = New System.Drawing.Point(169, 227)
        Me.tbxTelefono.Name = "tbxTelefono"
        Me.tbxTelefono.Size = New System.Drawing.Size(170, 20)
        Me.tbxTelefono.TabIndex = 12
        '
        'lbTelefono
        '
        Me.lbTelefono.AutoSize = True
        Me.lbTelefono.Font = New System.Drawing.Font("Candara Light", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbTelefono.Location = New System.Drawing.Point(35, 216)
        Me.lbTelefono.Name = "lbTelefono"
        Me.lbTelefono.Size = New System.Drawing.Size(113, 33)
        Me.lbTelefono.TabIndex = 13
        Me.lbTelefono.Text = "Telefono"
        '
        'btnMod
        '
        Me.btnMod.Location = New System.Drawing.Point(219, 308)
        Me.btnMod.Name = "btnMod"
        Me.btnMod.Size = New System.Drawing.Size(142, 50)
        Me.btnMod.TabIndex = 14
        Me.btnMod.Text = "Modificar"
        Me.btnMod.UseVisualStyleBackColor = True
        '
        'ButtonBuscar
        '
        Me.ButtonBuscar.Location = New System.Drawing.Point(102, 364)
        Me.ButtonBuscar.Name = "ButtonBuscar"
        Me.ButtonBuscar.Size = New System.Drawing.Size(204, 50)
        Me.ButtonBuscar.TabIndex = 15
        Me.ButtonBuscar.Text = "Buscar"
        Me.ButtonBuscar.UseVisualStyleBackColor = True
        '
        'PBLogo
        '
        Me.PBLogo.Image = Global.Veterinaria.My.Resources.Resources.LogoVeterinaria
        Me.PBLogo.Location = New System.Drawing.Point(480, 37)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(122, 130)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PBLogo.TabIndex = 16
        Me.PBLogo.TabStop = False
        '
        'inicioPersona
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(614, 426)
        Me.Controls.Add(Me.PBLogo)
        Me.Controls.Add(Me.ButtonBuscar)
        Me.Controls.Add(Me.btnMod)
        Me.Controls.Add(Me.lbTelefono)
        Me.Controls.Add(Me.tbxTelefono)
        Me.Controls.Add(Me.listaTelefonos)
        Me.Controls.Add(Me.btnTel)
        Me.Controls.Add(Me.tbxRes)
        Me.Controls.Add(Me.LabelCi)
        Me.Controls.Add(Me.LabelNom)
        Me.Controls.Add(Me.LabelDirec)
        Me.Controls.Add(Me.tbxNom)
        Me.Controls.Add(Me.tbxCI)
        Me.Controls.Add(Me.ButtonInicio)
        Me.Controls.Add(Me.tbxDirecc)
        Me.Controls.Add(Me.LabelTituloP)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "inicioPersona"
        Me.Text = "inicioPersona"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelTituloP As Label
    Friend WithEvents tbxDirecc As TextBox
    Friend WithEvents ButtonInicio As Button
    Friend WithEvents tbxCI As TextBox
    Friend WithEvents tbxNom As TextBox
    Friend WithEvents LabelDirec As Label
    Friend WithEvents LabelNom As Label
    Friend WithEvents LabelCi As Label
    Friend WithEvents tbxRes As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents InicioToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnTel As Button
    Friend WithEvents listaTelefonos As ListView
    Friend WithEvents tbxTelefono As TextBox
    Friend WithEvents lbTelefono As Label

    Friend WithEvents btnMod As Button
    Friend WithEvents ButtonBuscar As Button
    Friend WithEvents listadordePersonasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents ListarMascotasToolStripMenuItem As ToolStripMenuItem
End Class
