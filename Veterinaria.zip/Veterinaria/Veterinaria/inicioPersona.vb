﻿Public Class inicioPersona

    Dim listaTelefono As New List(Of Integer)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tbxTelefono.Enabled = False
        tbxDirecc.Enabled = False
        tbxNom.Enabled = False

    End Sub

    Private Sub ButtonInicio_Click(sender As Object, e As EventArgs) Handles ButtonInicio.Click
        Try
            Dim Nombre As String
            Nombre = tbxNom.Text


            Dim CI As Integer
            CI = tbxCI.Text

            Dim Direccion As String
            Direccion = tbxDirecc.Text

            Dim Telefono As String
            Telefono = tbxTelefono.Text

            Dim newPersona As New Persona()
            newPersona.CI = CI
            newPersona.Nombre = Nombre
            newPersona.Direccion = Direccion
            newPersona.ListaTelefono = listaTelefono
            'La segunda empieza en minuscula'

            'Aca deberiamos llamar a la logica'
            Dim logica As New LogicaPersona
            logica.altaPersona(newPersona)
        Catch ex As Exception
            MsgBox("Tuviste un error: " + ex.Message)
        End Try



    End Sub

    Private Sub tbxCI_TextChanged(sender As Object, e As EventArgs) Handles tbxCI.TextChanged

    End Sub

    Private Sub LabelTituloP_Click(sender As Object, e As EventArgs) Handles LabelTituloP.Click

    End Sub

    Private Sub MToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MToolStripMenuItem.Click
        inicioMascota.Show()
    End Sub

    Private Sub InicioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InicioToolStripMenuItem.Click
        inicio.Show()
    End Sub

    Private Sub btnTel_Click(sender As Object, e As EventArgs) Handles btnTel.Click
        Dim telefono As Integer
        telefono = tbxTelefono.Text

        listaTelefonos.Items.Add(telefono)
        listaTelefono.Add(telefono)

        tbxTelefono.Text = ""
    End Sub


    Private Sub btnMod_Click(sender As Object, e As EventArgs) Handles btnMod.Click
        Dim personaMod As New Persona
        personaMod.CI = tbxCI.Text
        personaMod.Nombre = tbxNom.Text
        personaMod.Direccion = tbxDirecc.Text

        Dim logicaMod As New LogicaPersona
        'logicaMod.modificarPersona(personaMod)

    End Sub

    Private Sub listaTelefonos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaTelefonos.SelectedIndexChanged
        Try
            Dim telefonoEscrito As String
            Dim telefonoEliminado As Integer
            telefonoEscrito = listaTelefonos.SelectedItems(0).SubItems(0).Text
            telefonoEliminado = Convert.ToInt32(telefonoEscrito)

            Dim iterador As Integer = 0
            While iterador < listaTelefono.Count
                If telefonoEliminado = listaTelefono.Item(iterador) Then
                    listaTelefono.Remove(telefonoEliminado)
                    iterador = listaTelefono.Count
                End If
                iterador = iterador + 1
            End While
            listaTelefonos.Clear()
            iterador = 0
            While iterador < listaTelefono.Count
                listaTelefonos.Items.Add(listaTelefono.Item(iterador))
                iterador = iterador + 1
            End While
        Catch ex As Exception

            MsgBox("Tuviste un error: " + ex.Message)

        End Try


    End Sub

    Private Sub ButtonBuscar_Click(sender As Object, e As EventArgs) Handles ButtonBuscar.Click
        Dim cedula As Integer
        cedula = tbxCI.Text
        Dim personaNueva As Persona
        Dim logica As New LogicaPersona
        personaNueva = logica.buscarPersona(cedula)

        If IsNothing(personaNueva) Then
        Else
            tbxNom.Text = personaNueva.Nombre
            tbxDirecc.Text = personaNueva.Direccion
        End If
    End Sub

    Private Sub listadordePersonasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles listadordePersonasToolStripMenuItem.Click
        PantallaListar.Show()
    End Sub

    Private Sub ListarMascotasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListarMascotasToolStripMenuItem.Click
        PantallaListarMascotas.Show()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class
