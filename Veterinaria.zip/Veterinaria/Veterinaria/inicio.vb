﻿Public Class inicio
    Private Sub MascotaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MascotaToolStripMenuItem.Click
        inicioMascota.Show()

    End Sub

    Private Sub PersonaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PersonaToolStripMenuItem.Click
        inicioPersona.Show()

    End Sub

    Private Sub ListarPersonasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListarPersonasToolStripMenuItem.Click
        PantallaListar.Show()
    End Sub

    Private Sub ListarMascotasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListarMascotasToolStripMenuItem.Click
        PantallaListarMascotas.Show()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class