﻿Public Class Mascota
    Private _id As Integer
    Private _dueño As Persona
    Private _nombre As String
    Private _añodenacimiento As Integer

    Public Property Dueño As Persona
        Get
            Return _dueño
        End Get
        Set(value As Persona)
            _dueño = value
        End Set
    End Property

    Public Property Nombre As String
        Get
            Return _nombre
        End Get
        Set(value As String)
            _nombre = value
        End Set
    End Property
    Public Property Añonacimiento As Integer
        Get
            Return _añodenacimiento
        End Get
        Set(value As Integer)
            _añodenacimiento = value
        End Set
    End Property

    Public Property Id As Integer
        Get
            Return _id
        End Get
        Set(value As Integer)
            _id = value
        End Set
    End Property
    Public Sub Mascotas()

    End Sub

    Public Sub Mascotas(nombre_ As String, dueño_ As Persona, añonacimiento_ As Integer, id_ As Integer)
        Nombre = nombre_
        Dueño = dueño_
        Añonacimiento = añonacimiento_
        Id = id_
    End Sub

End Class

