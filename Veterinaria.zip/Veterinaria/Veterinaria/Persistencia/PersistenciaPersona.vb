﻿Public Class PersistenciaPersona
    Sub New()
    End Sub

    Dim conetionPP = New Npgsql.NpgsqlConnection
    Public Sub altaPersona(personaUser As Persona)
        Try
            Dim classcnn = New Conexion
            conetionPP = classcnn.AbrirConexion
            Dim cadenaDeComandos As String
            cadenaDeComandos = "insert into persona(ci, nombre, direccion) values (@ci, @nombre, @direccion)"
            Dim cmd As New Npgsql.NpgsqlCommand
            cmd.CommandText = cadenaDeComandos
            cmd.Connection = conetionPP
            cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaUser.CI
            cmd.Parameters.Add("@nombre", NpgsqlTypes.NpgsqlDbType.Varchar, 50).Value = personaUser.Nombre
            cmd.Parameters.Add("@direccion", NpgsqlTypes.NpgsqlDbType.Varchar, 80).Value = personaUser.Direccion

            Dim resultado As Integer
            resultado = cmd.ExecuteNonQuery()
            'Esto debe ser la alta de telefono
            If resultado = 1 Then
                Dim i = 0
                While i < personaUser.ListaTelefono.Count

                    cadenaDeComandos = "insert into telefonos(ci,telefono) values (@ci, @telefono)"
                    cmd.CommandText = cadenaDeComandos

                    cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaUser.CI
                    cmd.Parameters.Add("@telefono", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaUser.ListaTelefono.Item(i)

                    resultado = cmd.ExecuteNonQuery
                    i = i + 1

                End While


            End If

        Catch ex As Exception
            Throw ex
        Finally
            conetionPP.close

        End Try
    End Sub

    Public Function BuscardorDePersona(ci As Integer) As Persona
        Dim personaBuscada As New Persona
        Try

            Dim claseConexion As New Conexion

            conetionPP = claseConexion.AbrirConexion
            Dim cmd As New Npgsql.NpgsqlCommand
            cmd.Connection = conetionPP

            Dim cadenaDeComandos = "Select * from persona where ci = @ci"

            cmd.CommandText = cadenaDeComandos
            cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = ci

            Dim Lector As Npgsql.NpgsqlDataReader
            Lector = cmd.ExecuteReader

            If Lector.HasRows Then
                Lector.Read()

                personaBuscada.CI = Convert.ToInt32(Lector(0).ToString)
                personaBuscada.Nombre = Lector(1).ToString
                personaBuscada.Direccion = Lector(2).ToString
            End If

        Catch ex As Exception

        End Try

        Return personaBuscada

    End Function

    Public Sub modificarPersona(personaMod As Persona)
        Try
            Dim clasCnn = New Conexion
            Dim cadenaDeComandos As String
            Dim variablex As Integer

            cadenaDeComandos = "IPDATE PERSONA SET ci = @ci, nombre = @nombre direccion = @direccion"

            conetionPP = clasCnn.AbrirConexion()
            Dim cmd As New Npgsql.NpgsqlCommand(cadenaDeComandos)


            cmd.Connection = conetionPP


            cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaMod.CI
            cmd.Parameters.Add("@nombre", NpgsqlTypes.NpgsqlDbType.Varchar, 50).Value = personaMod.Nombre
            cmd.Parameters.Add("@direccion", NpgsqlTypes.NpgsqlDbType.Varchar, 70).Value = personaMod.Direccion

            variablex = cmd.ExecuteNonQuery()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function listadordePersonas() As List(Of Persona)
        Dim xss As New List(Of Persona)
        Try
            Dim Persona As New Persona
            Dim ClaseSnl As New Conexion
            conetionPP = ClaseSnl.AbrirConexion
            Dim cmd = New Npgsql.NpgsqlCommand
            cmd.Connection = conetionPP

            Dim cadenaDeComandos = "SELECT * FROM Persona "

            cmd.CommandText = cadenaDeComandos
            Dim Lector As Npgsql.NpgsqlDataReader = cmd.ExecuteReader

            While Lector.Read()
                Dim newPersona As New Persona
                newPersona.CI = Lector(0).ToString
                newPersona.Nombre = Lector(1).ToString
                newPersona.Direccion = Lector(2).ToString

                xss.Add(newPersona)
            End While
        Catch ex As Exception
            Throw ex
        Finally
            conetionPP.close
        End Try
        Return xss
    End Function

End Class
