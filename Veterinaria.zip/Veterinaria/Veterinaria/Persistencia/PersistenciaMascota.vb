﻿Public Class PersistenciaMascota
    Dim conetionPP = New Npgsql.NpgsqlConnection
    Public Sub altaMascota(mascotaDueño As Mascota)
        Try
            Dim classcnn = New Conexion
            conetionPP = classcnn.AbrirConexion
            Dim cadenaDeComandos As String
            cadenaDeComandos = "INSERT INTO MASCOTA(id, ci, nombre, añonacimiento) values (@id, @ci, @nombre, @añonacimiento)"
            Dim cmd As New Npgsql.NpgsqlCommand
            cmd.CommandText = cadenaDeComandos
            cmd.Connection = conetionPP
            cmd.Parameters.Add("@id", NpgsqlTypes.NpgsqlDbType.Integer).Value = mascotaDueño.id
            cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = mascotaDueño.Dueño
            cmd.Parameters.Add("@nombre", NpgsqlTypes.NpgsqlDbType.Varchar, 50).Value = mascotaDueño.Nombre
            cmd.Parameters.Add("@añonacimiento", NpgsqlTypes.NpgsqlDbType.Integer).Value = mascotaDueño.Añonacimiento

            Dim resultado As Integer
            resultado = cmd.ExecuteNonQuery()

        Catch ex As Exception
            Throw ex
        Finally
            conetionPP.close

        End Try
    End Sub

    Public Function BuscarMascota(id As Integer) As Mascota
        Dim mascotaBuscada As New Mascota
        Try

            Dim claseConexion As New Conexion

            conetionPP = claseConexion.AbrirConexion
            Dim cmd As New Npgsql.NpgsqlCommand
            cmd.Connection = conetionPP

            Dim cadenaDeComandos = "SELECT * FROM Mascota WHERE id = @id"

            cmd.CommandText = cadenaDeComandos
            cmd.Parameters.Add("@id", NpgsqlTypes.NpgsqlDbType.Integer).Value = id

            Dim Lector As Npgsql.NpgsqlDataReader
            Lector = cmd.ExecuteReader

        Catch ex As Exception

        End Try

        Return mascotaBuscada

    End Function


    Public Function listarPMascota() As List(Of Mascota)
        Dim xss As New List(Of Mascota)
        Try
            Dim Mascota As New Mascota
            Dim ClaseSnl As New Conexion
            conetionPP = ClaseSnl.AbrirConexion
            Dim cmd = New Npgsql.NpgsqlCommand
            cmd.Connection = conetionPP

            Dim cadenaDeComandos = "SELECT * FROM Mascota "

            cmd.CommandText = cadenaDeComandos
            Dim Lector As Npgsql.NpgsqlDataReader = cmd.ExecuteReader

            While Lector.Read()
                Dim newMascota As New Mascota
                newMascota.id = Convert.ToInt32(Lector(0).ToString)
                newMascota.Nombre = Lector(1).ToString
                newMascota.Añonacimiento = Convert.ToInt32(Lector(2).ToString)

                xss.Add(newMascota)
            End While
        Catch ex As Exception
            Throw ex
        Finally
            conetionPP.close
        End Try
        Return xss
    End Function

End Class