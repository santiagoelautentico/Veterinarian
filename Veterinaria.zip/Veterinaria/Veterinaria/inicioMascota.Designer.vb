﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class inicioMascota
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelTituloM = New System.Windows.Forms.Label()
        Me.LabelD = New System.Windows.Forms.Label()
        Me.LabelCI = New System.Windows.Forms.Label()
        Me.LabelAnio = New System.Windows.Forms.Label()
        Me.LabelNom = New System.Windows.Forms.Label()
        Me.tbxAnio = New System.Windows.Forms.TextBox()
        Me.tbxID = New System.Windows.Forms.TextBox()
        Me.tbxCI = New System.Windows.Forms.TextBox()
        Me.tbxNom = New System.Windows.Forms.TextBox()
        Me.ButtonInicio = New System.Windows.Forms.Button()
        Me.tbxRes = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.InicioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MascotaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.listadordePersonasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListarMascotasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelTituloM
        '
        Me.LabelTituloM.AutoSize = True
        Me.LabelTituloM.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTituloM.Location = New System.Drawing.Point(15, 35)
        Me.LabelTituloM.Name = "LabelTituloM"
        Me.LabelTituloM.Size = New System.Drawing.Size(300, 39)
        Me.LabelTituloM.TabIndex = 1
        Me.LabelTituloM.Text = "Inicio de mascota"
        '
        'LabelD
        '
        Me.LabelD.AutoSize = True
        Me.LabelD.Font = New System.Drawing.Font("Candara Light", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelD.Location = New System.Drawing.Point(18, 116)
        Me.LabelD.Name = "LabelD"
        Me.LabelD.Size = New System.Drawing.Size(39, 33)
        Me.LabelD.TabIndex = 8
        Me.LabelD.Text = "ID"
        '
        'LabelCI
        '
        Me.LabelCI.AutoSize = True
        Me.LabelCI.Font = New System.Drawing.Font("Candara Light", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelCI.Location = New System.Drawing.Point(18, 148)
        Me.LabelCI.Name = "LabelCI"
        Me.LabelCI.Size = New System.Drawing.Size(37, 33)
        Me.LabelCI.TabIndex = 9
        Me.LabelCI.Text = "CI"
        '
        'LabelAnio
        '
        Me.LabelAnio.AutoSize = True
        Me.LabelAnio.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.LabelAnio.Location = New System.Drawing.Point(2, 233)
        Me.LabelAnio.Name = "LabelAnio"
        Me.LabelAnio.Size = New System.Drawing.Size(205, 31)
        Me.LabelAnio.TabIndex = 10
        Me.LabelAnio.Text = "Año Nacimiento"
        '
        'LabelNom
        '
        Me.LabelNom.AutoSize = True
        Me.LabelNom.Font = New System.Drawing.Font("Candara Light", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNom.Location = New System.Drawing.Point(18, 182)
        Me.LabelNom.Name = "LabelNom"
        Me.LabelNom.Size = New System.Drawing.Size(108, 33)
        Me.LabelNom.TabIndex = 11
        Me.LabelNom.Text = "Nombre"
        '
        'tbxAnio
        '
        Me.tbxAnio.Location = New System.Drawing.Point(213, 244)
        Me.tbxAnio.Name = "tbxAnio"
        Me.tbxAnio.Size = New System.Drawing.Size(170, 20)
        Me.tbxAnio.TabIndex = 12
        '
        'tbxID
        '
        Me.tbxID.Location = New System.Drawing.Point(134, 128)
        Me.tbxID.Name = "tbxID"
        Me.tbxID.Size = New System.Drawing.Size(170, 20)
        Me.tbxID.TabIndex = 13
        '
        'tbxCI
        '
        Me.tbxCI.Location = New System.Drawing.Point(134, 160)
        Me.tbxCI.Name = "tbxCI"
        Me.tbxCI.Size = New System.Drawing.Size(170, 20)
        Me.tbxCI.TabIndex = 14
        '
        'tbxNom
        '
        Me.tbxNom.Location = New System.Drawing.Point(134, 193)
        Me.tbxNom.Name = "tbxNom"
        Me.tbxNom.Size = New System.Drawing.Size(170, 20)
        Me.tbxNom.TabIndex = 15
        '
        'ButtonInicio
        '
        Me.ButtonInicio.Location = New System.Drawing.Point(63, 308)
        Me.ButtonInicio.Name = "ButtonInicio"
        Me.ButtonInicio.Size = New System.Drawing.Size(142, 50)
        Me.ButtonInicio.TabIndex = 16
        Me.ButtonInicio.Text = "Aceptar"
        Me.ButtonInicio.UseVisualStyleBackColor = True
        '
        'tbxRes
        '
        Me.tbxRes.AutoSize = True
        Me.tbxRes.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.tbxRes.Location = New System.Drawing.Point(60, 374)
        Me.tbxRes.Name = "tbxRes"
        Me.tbxRes.Size = New System.Drawing.Size(17, 17)
        Me.tbxRes.TabIndex = 17
        Me.tbxRes.Text = "X"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InicioToolStripMenuItem, Me.MascotaToolStripMenuItem, Me.listadordePersonasToolStripMenuItem, Me.ListarMascotasToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(614, 24)
        Me.MenuStrip1.TabIndex = 18
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'InicioToolStripMenuItem
        '
        Me.InicioToolStripMenuItem.Name = "InicioToolStripMenuItem"
        Me.InicioToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.InicioToolStripMenuItem.Text = "Inicio"
        '
        'MascotaToolStripMenuItem
        '
        Me.MascotaToolStripMenuItem.Name = "MascotaToolStripMenuItem"
        Me.MascotaToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.MascotaToolStripMenuItem.Text = "Persona"
        '
        'listadordePersonasToolStripMenuItem
        '
        Me.listadordePersonasToolStripMenuItem.Name = "listadordePersonasToolStripMenuItem"
        Me.listadordePersonasToolStripMenuItem.Size = New System.Drawing.Size(97, 20)
        Me.listadordePersonasToolStripMenuItem.Text = "Listar Personas"
        '
        'ListarMascotasToolStripMenuItem
        '
        Me.ListarMascotasToolStripMenuItem.Name = "ListarMascotasToolStripMenuItem"
        Me.ListarMascotasToolStripMenuItem.Size = New System.Drawing.Size(100, 20)
        Me.ListarMascotasToolStripMenuItem.Text = "Listar Mascotas"
        '
        'PBLogo
        '
        Me.PBLogo.Image = Global.Veterinaria.My.Resources.Resources.LogoVeterinaria
        Me.PBLogo.Location = New System.Drawing.Point(468, 52)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(122, 148)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PBLogo.TabIndex = 19
        Me.PBLogo.TabStop = False
        '
        'inicioMascota
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(614, 426)
        Me.Controls.Add(Me.PBLogo)
        Me.Controls.Add(Me.tbxRes)
        Me.Controls.Add(Me.ButtonInicio)
        Me.Controls.Add(Me.tbxNom)
        Me.Controls.Add(Me.tbxCI)
        Me.Controls.Add(Me.tbxID)
        Me.Controls.Add(Me.tbxAnio)
        Me.Controls.Add(Me.LabelNom)
        Me.Controls.Add(Me.LabelAnio)
        Me.Controls.Add(Me.LabelCI)
        Me.Controls.Add(Me.LabelD)
        Me.Controls.Add(Me.LabelTituloM)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Enabled = False
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "inicioMascota"
        Me.Text = "inicioMascota"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelTituloM As Label
    Friend WithEvents LabelD As Label
    Friend WithEvents LabelCI As Label
    Friend WithEvents LabelAnio As Label
    Friend WithEvents LabelNom As Label
    Friend WithEvents tbxAnio As TextBox
    Friend WithEvents tbxID As TextBox
    Friend WithEvents tbxCI As TextBox
    Friend WithEvents tbxNom As TextBox
    Friend WithEvents ButtonInicio As Button
    Friend WithEvents tbxRes As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents InicioToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MascotaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents listadordePersonasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ListarMascotasToolStripMenuItem As ToolStripMenuItem
End Class
