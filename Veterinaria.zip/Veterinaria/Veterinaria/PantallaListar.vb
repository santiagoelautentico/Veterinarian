﻿Class PantallaListar
    Dim user As New Persona
    Private Sub PantallaListar_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        ListaPersonas.Items.Clear()
        Dim logica As New LogicaPersona
        Dim lista As New List(Of Persona)
        lista = logica.listadordePersona()
        Dim i As Integer
        i = logica.listadordePersona.Count - 1
        Dim item As ListViewItem
        Dim arra(3) As String

        While i <> -1
            arra(0) = lista(i).CI
            arra(1) = lista(i).Nombre
            arra(2) = lista(i).Direccion

            item = New ListViewItem(arra)
            ListaPersonas.Items.Add(item)
            i = i - 1


        End While
    End Sub


    Private Sub MToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MToolStripMenuItem.Click
        inicioMascota.Show()
    End Sub

    Private Sub InicioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InicioToolStripMenuItem.Click
        inicio.Show()
    End Sub

    Private Sub PersonaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PersonaToolStripMenuItem.Click
        inicioPersona.Show()
    End Sub

    Private Sub listadordePersonasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles listadordePersonasToolStripMenuItem.Click
        PantallaListarMascotas.Show()
    End Sub
End Class