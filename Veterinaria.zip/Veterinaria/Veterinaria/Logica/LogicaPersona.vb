﻿Public Class LogicaPersona
    Public Sub altaPersona(personaUser As Persona)

        Dim persistencia As New PersistenciaPersona
        persistencia.altaPersona(personaUser)
    End Sub

    Public Function buscadorDePersona(CI As Integer) As Persona
        Dim persistencia As New PersistenciaPersona
        Return persistencia.BuscardorDePersona(CI)

    End Function

    Friend Function listadordePersona() As List(Of Persona)
        Throw New NotImplementedException()
    End Function

    Public Function listardorDePersona() As List(Of Persona)
        Dim persistencia As New PersistenciaPersona
        Return persistencia.listadordePersonas()

    End Function

    Friend Function buscarPersona(cedula As Integer) As Persona
        Throw New NotImplementedException()
    End Function
End Class
