﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formulario_mascota
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Txt_Id = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_CI = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_Nombre = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Txt_AñoNacimiento = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button_aceptar = New System.Windows.Forms.Button()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Txt_Resultado = New System.Windows.Forms.Label()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Txt_Id
        '
        Me.Txt_Id.Location = New System.Drawing.Point(221, 77)
        Me.Txt_Id.Name = "Txt_Id"
        Me.Txt_Id.Size = New System.Drawing.Size(100, 20)
        Me.Txt_Id.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(81, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(81, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 21)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "CI"
        '
        'Txt_CI
        '
        Me.Txt_CI.Location = New System.Drawing.Point(221, 108)
        Me.Txt_CI.Name = "Txt_CI"
        Me.Txt_CI.Size = New System.Drawing.Size(100, 20)
        Me.Txt_CI.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(79, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 21)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Nombre"
        '
        'Txt_Nombre
        '
        Me.Txt_Nombre.Location = New System.Drawing.Point(221, 140)
        Me.Txt_Nombre.Name = "Txt_Nombre"
        Me.Txt_Nombre.Size = New System.Drawing.Size(100, 20)
        Me.Txt_Nombre.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(79, 175)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 21)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Año nacimiento"
        '
        'Txt_AñoNacimiento
        '
        Me.Txt_AñoNacimiento.Location = New System.Drawing.Point(221, 178)
        Me.Txt_AñoNacimiento.Name = "Txt_AñoNacimiento"
        Me.Txt_AñoNacimiento.Size = New System.Drawing.Size(100, 20)
        Me.Txt_AñoNacimiento.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(82, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(129, 32)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Mascota"
        '
        'Button_aceptar
        '
        Me.Button_aceptar.Cursor = System.Windows.Forms.Cursors.Default
        Me.Button_aceptar.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_aceptar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button_aceptar.Location = New System.Drawing.Point(221, 225)
        Me.Button_aceptar.Name = "Button_aceptar"
        Me.Button_aceptar.Size = New System.Drawing.Size(100, 28)
        Me.Button_aceptar.TabIndex = 9
        Me.Button_aceptar.Text = "Aceptar"
        Me.Button_aceptar.UseVisualStyleBackColor = True
        '
        'Txt_Resultado
        '
        Me.Txt_Resultado.AutoSize = True
        Me.Txt_Resultado.Location = New System.Drawing.Point(352, 235)
        Me.Txt_Resultado.Name = "Txt_Resultado"
        Me.Txt_Resultado.Size = New System.Drawing.Size(12, 13)
        Me.Txt_Resultado.TabIndex = 10
        Me.Txt_Resultado.Text = "x"
        '
        'formulario_mascota
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PeachPuff
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Txt_Resultado)
        Me.Controls.Add(Me.Button_aceptar)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_AñoNacimiento)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Txt_Nombre)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Txt_CI)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_Id)
        Me.Name = "formulario_mascota"
        Me.Text = "formulario_mascota"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txt_Id As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Txt_CI As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Txt_Nombre As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Txt_AñoNacimiento As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Button_aceptar As Button
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents Txt_Resultado As Label
End Class
