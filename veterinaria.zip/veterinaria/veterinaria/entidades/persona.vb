﻿Public Class persona
    Dim cedula As Integer
    Dim direccion As String
    Dim nombre As String

    Public Sub New(cedula As Integer, direccion As String, nombre As String)
        Me.cedula = cedula
        Me.direccion = direccion
        Me.nombre = nombre
    End Sub

    Public Overrides Function Equals(obj As Object) As Boolean
        Dim persona = TryCast(obj, persona)
        Return persona IsNot Nothing AndAlso
               cedula = persona.cedula AndAlso
               direccion = persona.direccion AndAlso
               nombre = persona.nombre
    End Function
End Class
