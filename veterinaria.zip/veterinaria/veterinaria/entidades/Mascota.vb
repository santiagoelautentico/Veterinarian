﻿Public Class Mascota
    Private id As Integer
    Private dueño As persona
    Private nombre As String
    Private añoNacimiento As Integer

    Public Sub New(id As Integer, dueño As persona, nombre As String, añoNacimiento As Integer)
        Me.id = id
        Me.dueño = dueño
        Me.nombre = nombre
        Me.añoNacimiento = añoNacimiento
    End Sub

    Public Property Id1 As Integer
        Get
            Return id
        End Get
        Set(value As Integer)
            id = value
        End Set
    End Property

    Public Property Dueño1 As persona
        Get
            Return dueño
        End Get
        Set(value As persona)
            dueño = value
        End Set
    End Property

    Public Property Nombre1 As String
        Get
            Return nombre
        End Get
        Set(value As String)
            nombre = value
        End Set
    End Property

    Public Property AñoNacimiento1 As Integer
        Get
            Return añoNacimiento
        End Get
        Set(value As Integer)
            añoNacimiento = value
        End Set
    End Property
End Class
