﻿Public Class LogicaPersona

End Class
