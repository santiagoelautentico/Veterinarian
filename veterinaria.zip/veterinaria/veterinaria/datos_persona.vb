﻿Public Class datos_persona

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Aceptar.Click
        Dim Id As Integer
        Id = Txt_Id.Text

        Dim Nombre As String
        Nombre = Txt_Nombre.Text

        Dim Direccion As String
        Direccion = Txt_Direccion.Text

        Dim Resultado As String
        Resultado = Id & " " & Nombre & " " & Direccion

        Txt_Resultado.Text = Resultado

    End Sub


End Class