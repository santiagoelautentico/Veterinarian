﻿Public Class PersistenciaMascota

End Class
