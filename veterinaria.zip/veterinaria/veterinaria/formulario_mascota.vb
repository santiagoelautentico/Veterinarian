﻿Public Class formulario_mascota

    Private Sub Button_aceptar_Click(sender As Object, e As EventArgs) Handles Button_aceptar.Click
        Dim Id As Integer
        Id = Txt_Id.Text

        Dim CI As Integer
        CI = Txt_CI.Text

        Dim Nombre As String
        Nombre = Txt_Nombre.Text

        Dim AñoDeNacimiento As String
        AñoDeNacimiento = Txt_AñoNacimiento.Text

        Dim Resultado As String
        Resultado = Id & "" & CI & " " & Nombre & " " & AñoDeNacimiento


        Txt_Resultado.Text = Resultado




    End Sub


End Class